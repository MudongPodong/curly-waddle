package org.chobo.metosapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MenteeMain1 extends AppCompatActivity {

    Toolbar mytoolbar;//포함
    Button go_mentolist;
    Button showList;
    TextView welcome;
    private ArrayList<MentoringData> arrayList;
    private MentoringAdapter mentoringadapter;
    private RecyclerView recyclerview;
    private LinearLayoutManager linearlayoutmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mentee_main1);
        mytoolbar=(Toolbar) findViewById(R.id.toolbar);   //포함
        setSupportActionBar(mytoolbar);                   //포함
        welcome=findViewById(R.id.textView24);


        recyclerview=(RecyclerView) findViewById(R.id.rv_mtlist3);

        linearlayoutmanager =new LinearLayoutManager(this);
        recyclerview.setLayoutManager(linearlayoutmanager);

        arrayList=new ArrayList<>();
        mentoringadapter=new MentoringAdapter(arrayList);
        recyclerview.setAdapter(mentoringadapter);
        showList=findViewById(R.id.bt_renew);


        go_mentolist=findViewById(R.id.button11);
        go_mentolist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=getIntent();
                String userName=intent2.getStringExtra("userName");

                Intent intent=new Intent(getApplicationContext(),MentoList.class);
                intent.putExtra("userName",userName);
                startActivity(intent);
            }
        });
        showList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    BufferedReader br=new BufferedReader(
                            new InputStreamReader(openFileInput("ClassServer"))
                    );
                    String s=null;
                    Intent intent3=getIntent();
                    String Mname=intent3.getStringExtra("userName");
                    while((s=br.readLine())!=null){
                        String []temp=s.split(",");
                        if(temp.length>=5){
                            if(temp[2].equals(Mname)){
                                MentoringData mentoringData=new MentoringData
                                        (R.mipmap.mentosicon_round,"멘토이름:","멘티이름:",temp[4],temp[1],temp[2],temp[0]);  //데이터 추가할때
                                arrayList.add(mentoringData);
                                mentoringadapter.notifyDataSetChanged();  //새로고침
                            }
                        }
                    }
                }catch(IOException e){}
            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {       //포함
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {    //포함
        switch(item.getItemId()){
            case R.id.menu1:
                Toast.makeText(getApplicationContext(),"선택창으로 이동하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent6=new Intent(getApplicationContext(),Choosementoring.class);
                startActivity(intent6);
                finish();
                break;

            case R.id.menu2:
                Toast.makeText(getApplicationContext(),"시스템이 종료되었습니다.",Toast.LENGTH_SHORT).show();
                moveTaskToBack(true);
                finishAndRemoveTask();
                android.os.Process.killProcess(android.os.Process.myPid());
                break;
            case R.id.menu3:
                Toast.makeText(getApplicationContext(),"로그아웃하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}

