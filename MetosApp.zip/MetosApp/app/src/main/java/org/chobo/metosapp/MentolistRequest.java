package org.chobo.metosapp;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MentolistRequest extends StringRequest {
    final static private String URL="http://jhng77.dothome.co.kr/loadDBtoJSON.php";     // http://jhng77.dothome.co.kr/findingmento.php
    private Map<String,String> map;
    public MentolistRequest(String userInterest, Response.Listener<String> listener){
        super(Method.POST,URL,listener,null);
        map=new HashMap<>();
        map.put("userInterest",userInterest);
    }

    protected Map<String,String> getParams() throws AuthFailureError{
        return map;
    }
}
