package org.chobo.metosapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MentoMain1 extends AppCompatActivity {

    Toolbar mytoolbar;                                    //포함
    Button showList;
    private ArrayList<MentoringData> arrayList;
    private MentoringAdapter mentoringAdapter;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mento_main1);
        mytoolbar=(Toolbar) findViewById(R.id.toolbar);   //포함
        setSupportActionBar(mytoolbar);                   //포함
        mytoolbar.setTitle("Mentos!");                    //포함
        mytoolbar.setTitleMarginStart(30);                //포함
        recyclerView=(RecyclerView) findViewById(R.id.rv_mtlist2);

        linearLayoutManager =new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        arrayList=new ArrayList<>();
        mentoringAdapter=new MentoringAdapter(arrayList);
        recyclerView.setAdapter(mentoringAdapter);

        showList=findViewById(R.id.bt_renew2);
        showList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    BufferedReader br4=new BufferedReader(
                            new InputStreamReader(openFileInput("ClassServer"))
                    );
                    String s=null;
                    Intent intent2=getIntent();
                    String Mname=intent2.getStringExtra("userName");
                    while((s= br4.readLine())!=null){
                        String[] temp=s.split(",");
                        if(temp.length>=5){
                            if(temp[1].equals(Mname)){
                                MentoringData mentoringData=new MentoringData
                                        (R.mipmap.mentosicon_round,"멘토이름:","멘티이름:",temp[4],temp[1],temp[2],temp[0]);  //데이터 추가할때
                                arrayList.add(mentoringData);
                                mentoringAdapter.notifyDataSetChanged();  //새로고침
                            }
                        }
                    }
                    br4.close();
                }catch(IOException e){}
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {       //포함
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {    //포함
        switch(item.getItemId()){
            case R.id.menu1:
                Toast.makeText(getApplicationContext(),"선택창으로 이동하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent6=new Intent(getApplicationContext(),Choosementoring.class);
                startActivity(intent6);
                finish();
                break;
            case R.id.menu2:
                Toast.makeText(getApplicationContext(),"시스템이 종료되었습니다.",Toast.LENGTH_SHORT).show();
                moveTaskToBack(true);
                finishAndRemoveTask();
                android.os.Process.killProcess(android.os.Process.myPid());
                break;
            case R.id.menu3:
                Toast.makeText(getApplicationContext(),"로그아웃하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();

        }

        return super.onOptionsItemSelected(item);
    }
}