package org.chobo.metosapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.*;
public class MentoList extends AppCompatActivity {         //데이터베이스에서 멘토자 데이터 가져오기
    Toolbar mytoolbar;//포함
    Button filtering;
    Button bt_MentoRequest;
    Button bt_no;
    TextView tx_check;

    EditText et_filter;
    private ArrayList<MentoringData> arrayList;
    private MentoringAdapter mentoringadapter;
    private RecyclerView recyclerview;
    private LinearLayoutManager linearlayoutmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mento_list);

        mytoolbar=(Toolbar) findViewById(R.id.toolbar);   //포함
        setSupportActionBar(mytoolbar);                   //포함
        filtering=findViewById(R.id.button12);
        et_filter=findViewById(R.id.et_filter);

        recyclerview=(RecyclerView) findViewById(R.id.rv_mtlist4);

        linearlayoutmanager =new LinearLayoutManager(this);
        recyclerview.setLayoutManager(linearlayoutmanager);

        arrayList=new ArrayList<>();
        mentoringadapter=new MentoringAdapter(arrayList);
        recyclerview.setAdapter(mentoringadapter);
        bt_MentoRequest=findViewById(R.id.bt_ok);
        bt_no=findViewById(R.id.bt_no);
        tx_check=findViewById(R.id.tx_check);

        filtering.setOnClickListener(new View.OnClickListener() {     //필터링해서 현재 멘토링목록을 출력한다
            @Override
            public void onClick(View view) {

                String filter=et_filter.getText().toString();
                et_filter.setVisibility(View.INVISIBLE);
                filtering.setVisibility(View.INVISIBLE);
                Response.Listener<String> responsListerner=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonobject=new JSONObject(response);
                            boolean success=jsonobject.getBoolean("success");
                            if(success){
                                bt_MentoRequest.setVisibility(View.VISIBLE);
                                bt_no.setVisibility(View.VISIBLE);
                                tx_check.setVisibility(View.VISIBLE);
                                String userName= jsonobject.getString("userName");
                                String userPhonenum=jsonobject.getString("userPhonenum");
                                String userTown= jsonobject.getString("userTown");

                                Toast.makeText(getApplicationContext(),"필터링에 성공하였습니다.",Toast.LENGTH_SHORT).show();
                                MentoringData mentoringData=new MentoringData(R.mipmap.ic_launcher_round,"멘티이름:","전화번호:","진행지역:",userName,userPhonenum,userTown);
                                arrayList.add(mentoringData);
                                mentoringadapter.notifyDataSetChanged();  //새로고침
                            }
                        } catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                };
                MentolistRequest mentolistRequest=new MentolistRequest(filter,responsListerner);
                RequestQueue queue= Volley.newRequestQueue(MentoList.this);
                queue.add(mentolistRequest);
            }
        });

        bt_MentoRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bt_MentoRequest.setVisibility(View.INVISIBLE);
                bt_no.setVisibility(View.INVISIBLE);
                tx_check.setVisibility(View.INVISIBLE);
                String name1=arrayList.get(0).getMt_name();
                Intent intent=getIntent();
                String name2=intent.getStringExtra("userName");
                String classname=et_filter.getText().toString();
                SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");


                Calendar now1=Calendar.getInstance() ;

                String startdate=sdf.format(now1.getTime());
                now1.add(Calendar.MONTH,1);
                String enddate=sdf.format(now1.getTime());
                String Notice="";
                try{
                    BufferedWriter bw=new BufferedWriter(
                            new OutputStreamWriter(openFileOutput("ClassServer",MODE_APPEND))
                    );
                    bw.write("\n"+classname+","+name1+","+name2+","+startdate+","+enddate+","+"...");
                    bw.close();
                    Toast.makeText(getApplicationContext(),"수업 등록완료",Toast.LENGTH_SHORT).show();
                    Intent intent2=new Intent(MentoList.this,MenteeMain1.class);
                    intent2.putExtra("userName",name2);
                    startActivity(intent2);
                }catch(IOException e) {
                    e.printStackTrace();
                }


            }
        });
        bt_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"수업신청이 취소되었습니다.",Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {       //포함
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {    //포함
        switch(item.getItemId()){
            case R.id.menu1:
                Toast.makeText(getApplicationContext(),"선택창으로 이동하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent6=new Intent(getApplicationContext(),Choosementoring.class);
                startActivity(intent6);
                finish();
                break;
            case R.id.menu2:
                Toast.makeText(getApplicationContext(),"시스템이 종료되었습니다.",Toast.LENGTH_SHORT).show();
                moveTaskToBack(true);
                finishAndRemoveTask();
                android.os.Process.killProcess(android.os.Process.myPid());
                break;
            case R.id.menu3:
                Toast.makeText(getApplicationContext(),"로그아웃하였습니다.",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
        }
        return super.onOptionsItemSelected(item);
    }
}