package org.chobo.metosapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;


public class Choosementoring extends AppCompatActivity {
    private TextView tv_name;
    private Button btn_mento,btn_mentee;
    Toolbar mytoolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosementoring);
        tv_name=findViewById(R.id.tv_name);
        btn_mento=findViewById(R.id.btn_mento);
        btn_mentee=findViewById(R.id.btn_mentee);
        mytoolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mytoolbar);              //@style/Theme.AppCompat.Light.NoActionBar

        Intent intent =getIntent();
        String userName=intent.getStringExtra("userName");
        tv_name.setText(userName);
        mytoolbar.setTitle("Mentos!");
        mytoolbar.setTitleMarginStart(30);

        btn_mento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=getIntent();
                String userName=intent2.getStringExtra("userName");

                Intent intent =new Intent(getApplicationContext(),MentoMain1.class);
                intent.putExtra("userName",userName);
                startActivity(intent);
            }
        });
        btn_mentee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=getIntent();
                String userName=intent2.getStringExtra("userName");

                Intent intent =new Intent(getApplicationContext(),MenteeMain1.class);
                intent.putExtra("userName",userName);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       switch(item.getItemId()){
           case R.id.menu1:
               Toast.makeText(getApplicationContext(),"선택창으로 이동하였습니다.",Toast.LENGTH_SHORT).show();
               Intent intent6=new Intent(getApplicationContext(),Choosementoring.class);
               startActivity(intent6);
               finish();
               break;
           case R.id.menu2:
               Toast.makeText(getApplicationContext(),"시스템이 종료되었습니다.",Toast.LENGTH_SHORT).show();
               moveTaskToBack(true);
               finishAndRemoveTask();
               android.os.Process.killProcess(android.os.Process.myPid());
               break;
           case R.id.menu3:
               Toast.makeText(getApplicationContext(),"로그아웃하였습니다.",Toast.LENGTH_SHORT).show();
               Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
               startActivity(intent);
               finish();

       }

        return super.onOptionsItemSelected(item);
    }
}