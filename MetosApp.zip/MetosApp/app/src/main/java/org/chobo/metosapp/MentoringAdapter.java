package org.chobo.metosapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MentoringAdapter extends RecyclerView.Adapter<MentoringAdapter.CustomViewHolder> {

    private ArrayList<MentoringData> arraylist;
    private Intent intent;
    public MentoringAdapter(ArrayList<MentoringData> arraylist) {
        this.arraylist = arraylist;
    }

    @NonNull
    @Override
    public MentoringAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {    //onCreate와 유사

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.mentoring_list,parent,false);   //mentoring_list를 보여주겠다
        CustomViewHolder holder=new CustomViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MentoringAdapter.CustomViewHolder holder,int position) {     //추가될때
        holder.iv_profile.setImageResource(arraylist.get(position).getIv_profile());
        holder.tv_name.setText(arraylist.get(position).getTv_name());
        holder.tv_interest.setText((arraylist.get(position).getTv_interest()));
        holder.tv_location.setText(arraylist.get(position).getTv_location());
        holder.mt_name.setText(arraylist.get(position).getMt_name());
        holder.mt_interest.setText(arraylist.get(position).getMt_interest());
        holder.mt_location.setText(arraylist.get(position).getMt_location());

        holder.itemView.setTag(position);   //눌렀을때
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String curName=holder.tv_name.getText().toString();    //클릭한 뷰에있는 정보를 보내기위한작업
                //Toast.makeText(view.getContext(),curName,Toast.LENGTH_SHORT).show();
                intent=new Intent(view.getContext(),ClassProgress.class);
                intent.putExtra("Mentoname",holder.mt_name.getText());
                intent.putExtra("interest",holder.mt_interest.getText());
                intent.putExtra("classname",holder.mt_location.getText());
                intent.putExtra("enddate",holder.tv_location.getText());
                view.getContext().startActivity(intent);
                Toast.makeText(view.getContext(), "클릭 되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {     //길게눌렀을때 삭제
            @Override
            public boolean onLongClick(View view) {
                remove(holder.getAdapterPosition());
                return true;
            }
        });

    }


    @Override
    public int getItemCount() {
        return (null != arraylist ? arraylist.size() : 0);
    }

    public void remove(int position){
        try{
            arraylist.remove(position);
            notifyItemRemoved(position);
        } catch(IndexOutOfBoundsException e){
            e.printStackTrace();
        }
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        protected ImageView iv_profile;
        protected TextView tv_name;
        protected TextView tv_interest;
        protected TextView tv_location;
        protected TextView mt_name;
        protected TextView mt_interest;
        protected TextView mt_location;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.iv_profile=(ImageView) itemView.findViewById(R.id.iv_profile10);
            this.tv_name=(TextView) itemView.findViewById(R.id.tv_name10);
            this.tv_interest=(TextView) itemView.findViewById(R.id.tv_interest10);
            this.tv_location=(TextView) itemView.findViewById(R.id.tv_location10);
            this.mt_name=(TextView) itemView.findViewById(R.id.mt_name10);
            this.mt_interest=(TextView) itemView.findViewById(R.id.mt_interest10);
            this.mt_location=(TextView) itemView.findViewById(R.id.mt_location10);
        }
    }
}
