package org.chobo.metosapp;

public class MentoringData {                 //현재 수업목록 보여주는거

    private int iv_profile10;         //이미지뷰
    private String tv_name10;         //'이름'칸
    private String tv_interest10;     //'수업분야'칸
    private String tv_location10;     //'진행지역'칸
    private String mt_name10;         //멘토 또는 멘티이름
    private String mt_interest10;     //멘토 또는 멘티의 수업분야
    private String mt_location10;     //멘터 또는 멘티의 진행지역  <---멘토지역을 따른다

    public MentoringData(int iv_profile, String tv_name, String tv_interest, String tv_location, String mt_name, String mt_interest, String mt_location) {
        this.iv_profile10 = iv_profile;
        this.tv_name10 = tv_name;
        this.tv_interest10 = tv_interest;
        this.tv_location10 = tv_location;
        this.mt_name10 = mt_name;
        this.mt_interest10 = mt_interest;
        this.mt_location10 = mt_location;
    }

    public int getIv_profile() {
        return iv_profile10;
    }

    public void setIv_profile(int iv_profile) {
        this.iv_profile10 = iv_profile;
    }

    public String getTv_name() {
        return tv_name10;
    }

    public void setTv_name(String tv_name) {
        this.tv_name10 = tv_name;
    }

    public String getTv_interest() {
        return tv_interest10;
    }

    public void setTv_interest(String tv_interest) {
        this.tv_interest10 = tv_interest;
    }

    public String getTv_location() {
        return tv_location10;
    }

    public void setTv_location(String tv_location) {
        this.tv_location10 = tv_location;
    }

    public String getMt_name() {
        return mt_name10;
    }

    public void setMt_name(String mt_name) {
        this.mt_name10 = mt_name;
    }

    public String getMt_interest() {
        return mt_interest10;
    }

    public void setMt_interest(String mt_interest) {
        this.mt_interest10 = mt_interest;
    }

    public String getMt_location() {
        return mt_location10;
    }

    public void setMt_location(String mt_location) {
        this.mt_location10 = mt_location;
    }
}
