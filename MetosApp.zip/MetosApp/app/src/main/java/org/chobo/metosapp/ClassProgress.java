package org.chobo.metosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ClassProgress extends AppCompatActivity {
    TextView tx_mentoname;
    TextView tx_menteename;
    TextView tx_classname;
    TextView tx_finish;
    TextView tx_progress;
    TextView tx_notice;
    Button resign;
    Button upload;

    double calculate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_progress);
        tx_mentoname=findViewById(R.id.tx_mento);
        tx_menteename=findViewById(R.id.tx_mentee);
        tx_classname=findViewById(R.id.tx_class);
        tx_finish=findViewById(R.id.tx_finish);
        tx_progress=findViewById(R.id.tx_progress);
        tx_notice=findViewById(R.id.tx_notice);
        resign=findViewById(R.id.bt_resign);
        upload=findViewById((R.id.bt_upload));

        Intent intent=getIntent();
        tx_mentoname.setText(intent.getStringExtra("Mentoname"));
        tx_menteename.setText(intent.getStringExtra("interest"));
        tx_classname.setText(intent.getStringExtra("classname"));
        tx_finish.setText(intent.getStringExtra("enddate"));

        String end=tx_finish.getText().toString();
        calculate=getProgress(end,end);
        tx_progress.setText(Double.toString(Math.round(calculate*100)/100.0));

        if(Double.parseDouble(tx_progress.getText().toString())>=100){
            try{
                BufferedReader br5=new BufferedReader(
                        new InputStreamReader(openFileInput("ClassServer"))
                );

                String s=null;
                Intent intent1=getIntent();
                String mentoname=intent1.getStringExtra("Mentoname");
                String menteename=intent1.getStringExtra("Menteename");
                StringBuilder sb=new StringBuilder();

                while((s=br5.readLine())!=null){
                    String[] temp=s.split(",");
                    if(temp.length>=5){
                        if(temp[1].equals(mentoname) && temp[2].equals(menteename)){
                            continue;
                        }else{
                            for(int i=0;i<temp.length;i++){
                                sb.append(temp[i]).append(",");
                            }
                        }
                    }
                }

                BufferedWriter bw5=new BufferedWriter(
                        new OutputStreamWriter(openFileOutput("ClassServer",MODE_PRIVATE))
                );
                bw5.write(sb.toString());
                bw5.close();
                br5.close();
                Toast.makeText(getApplicationContext(),"수업이 삭제되었습니다.(다시로그인해주세요.)",Toast.LENGTH_SHORT).show();
            }catch(IOException e){}
        }

        try{
            BufferedReader br3=new BufferedReader(
                    new InputStreamReader(openFileInput("ClassServer"))
            );
            String s=null;
            while((s=br3.readLine())!=null){
                String[] temp=s.split(",");
                if(temp.length>=5){
                    if(temp[1].equals(tx_mentoname.getText().toString()) && temp[2].equals(tx_menteename.getText().toString())){
                        tx_notice.setText(temp[5]);
                    }
                }
            }
        }catch(IOException e){}



        resign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=new Intent(ClassProgress.this,ClassResign.class);
                intent2.putExtra("Mentoname",tx_mentoname.getText().toString());
                intent2.putExtra("Menteename",tx_menteename.getText().toString());
                startActivity(intent2);
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3=new Intent(ClassProgress.this,NoticeUpdown.class);
                intent3.putExtra("Mentoname",tx_mentoname.getText().toString());
                intent3.putExtra("Menteename",tx_menteename.getText().toString());
                startActivity(intent3);
            }
        });
    }

    double getProgress(String startdate,String enddate){
        String[] end1=enddate.split("-");
        Calendar now=Calendar.getInstance();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        String now1=sdf.format(now.getTime());
        String[] now2=now1.split("-");
        double day1=0;
        double day2=0;
        double result=0;

        if(now2[1].equals("01")  || now2[1].equals("03") || now2[1].equals("10") || now2[1].equals("12")
        || now2[1].equals("05") || now2[1].equals("07") || now2[1].equals("08")){
            day1=31.0-Integer.parseInt(now2[2]);
            day2=day1+Integer.parseInt(end1[2]);
            result=(31.0-day2)/31.0;
        }else if(now2[1].equals("02")){
            day1=28.0-Integer.parseInt(now2[2]);
            day2=day1+Integer.parseInt(end1[2]);
            result=(28.0-day2)/28.0;
        }else{
            day1=30.0-Integer.parseInt(now2[2]);
            day2=day1+Integer.parseInt(end1[2]);
            result=(30.0-day2)/30.0;
        }

        result*=100;
        return result;
    }
}