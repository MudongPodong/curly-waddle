package org.chobo.metosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class NoticeUpdown extends AppCompatActivity {
    EditText et_upload;
    Button bt_up;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_updown);

        et_upload=findViewById(R.id.et_up);
        bt_up=findViewById(R.id.bt_upload2);


        bt_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    BufferedReader br2=new BufferedReader(
                            new InputStreamReader(openFileInput("ClassServer"))
                    );
                    String s=null;
                    Intent intent5=getIntent();
                    String mentoname=intent5.getStringExtra("Mentoname");
                    String txt=et_upload.getText().toString();                     //공지사항 내용
                    String menteename=intent5.getStringExtra("Menteename");
                    StringBuilder sb1=new StringBuilder();

                    while((s=br2.readLine())!=null){
                        String[] temp=s.split(",");
                        if(temp.length>=5){
                            if(temp[1].equals(mentoname) && temp[2].equals(menteename)){
                                temp[5]=txt;
                                for(int i=0;i<temp.length;i++){
                                    sb1.append(temp[i]).append(",");
                                }
                            }else{
                                for(int i=0;i<temp.length;i++){
                                    sb1.append(temp[i]).append(",");
                                }
                            }
                        }
                        sb1.append("\n");
                    }
                    BufferedWriter bw2=new BufferedWriter(
                            new OutputStreamWriter(openFileOutput("ClassServer",MODE_PRIVATE))
                    );
                    bw2.write(sb1.toString());
                    bw2.close();
                    br2.close();
                    Toast.makeText(getApplicationContext(),"메인화면으로 돌아가세요.(새로고침 후 갱신)",Toast.LENGTH_SHORT).show();
                    finish();
                }catch(IOException e){}

            }
        });
    }
}