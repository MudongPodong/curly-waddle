package org.chobo.metosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ClassResign extends AppCompatActivity {
    Button bt_yes;
    Button bt_no;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_resign);
        bt_yes=findViewById(R.id.bt_yes2);
        bt_no=findViewById(R.id.bt_no2);


        bt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    BufferedReader br1=new BufferedReader(
                            new InputStreamReader(openFileInput("ClassServer"))
                    );

                    String s=null;
                    Intent intent1=getIntent();
                    String mentoname=intent1.getStringExtra("Mentoname");
                    String menteename=intent1.getStringExtra("Menteename");
                    StringBuilder sb=new StringBuilder();

                    while((s=br1.readLine())!=null){
                        String[] temp=s.split(",");
                        if(temp.length>=5){
                            if(temp[1].equals(mentoname) && temp[2].equals(menteename)){
                                continue;
                            }else{
                                for(int i=0;i<temp.length;i++){
                                    sb.append(temp[i]).append(",");
                                }
                            }
                        }
                    }

                    BufferedWriter bw1=new BufferedWriter(
                            new OutputStreamWriter(openFileOutput("ClassServer",MODE_PRIVATE))
                    );
                    bw1.write(sb.toString());
                    bw1.close();
                    br1.close();
                    Toast.makeText(getApplicationContext(),"수업이 삭제되었습니다.(다시로그인해주세요.)",Toast.LENGTH_SHORT).show();
                }catch(IOException e){}
            }
        });

        bt_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"수업이 삭제가 취소되었습니다.",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}