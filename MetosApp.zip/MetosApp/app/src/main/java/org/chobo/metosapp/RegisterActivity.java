package org.chobo.metosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {
    private EditText et_id2,et_pass2,et_name,et_age,et_sex,et_Phonenum,et_location,et_email,et_interest,et_menteeinterest;
    private Button btn_register2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_id2=findViewById(R.id.et_id2);
        et_pass2=findViewById(R.id.et_pass2);
        et_name=findViewById(R.id.et_name);
        et_age=findViewById(R.id.et_age);
        et_sex=findViewById(R.id.et_sex);
        et_Phonenum=findViewById(R.id.et_Phonenum);
        et_location=findViewById(R.id.et_location);
        et_email=findViewById(R.id.et_email);
        et_interest=findViewById(R.id.et_interest);
        et_menteeinterest=findViewById(R.id.et_interestmentee);

        btn_register2=findViewById(R.id.btn_register2);
        btn_register2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userID=et_id2.getText().toString();
                String userPass=et_pass2.getText().toString();
                String userName=et_name.getText().toString();
                int userAge=Integer.parseInt(et_age.getText().toString());
                String userSex=et_sex.getText().toString();
                String userPhonenum=et_Phonenum.getText().toString();
                String userLocation=et_location.getText().toString();
                String userEmail=et_email.getText().toString();
                String userInterest=et_interest.getText().toString();
                String userInterest2=et_menteeinterest.getText().toString();

                Response.Listener<String> responseListener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonobject=new JSONObject(response);
                            boolean success=jsonobject.getBoolean("success");
                            if(success){
                                Toast.makeText(getApplicationContext(),"회원등록 성공! 환영합니다!",Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(RegisterActivity.this,LoginActivity.class);
                                startActivity(intent);
                            } else{
                                Toast.makeText(getApplicationContext(),"등록에 실패하였습니다. 다시한번확인해주세요.",Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                };
                Toast.makeText(getApplicationContext(),"클릭성공",Toast.LENGTH_SHORT).show();
                RegisterRequest registerRequest=new RegisterRequest(userID,userPass,userName,userAge,userSex,userPhonenum,userLocation,
                        userEmail,userInterest,userInterest2,responseListener);
                RequestQueue queue= Volley.newRequestQueue(RegisterActivity.this);
                queue.add(registerRequest);
            }
        });

    }
}