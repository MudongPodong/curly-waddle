package org.chobo.metosapp;

import com.android.volley.AuthFailureError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.Response;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class RegisterClass extends StringRequest {
    final static private String URL="http://jhng77.dothome.co.kr/makeClass.php";
    private Map<String,String>map;
    public RegisterClass(String ClassName,String Mentoname, String Menteename, String startdate,
                         String enddate,String Notice,Response.Listener<String> listener){
        super(Method.POST,URL,listener,null);

        map=new HashMap<>();
        map.put("Classname",ClassName);
        map.put("startdate",startdate);
        map.put("enddate",enddate);
        map.put("Mentoname",Mentoname);
        map.put("Menteename",Menteename);
        map.put("Notice",Notice);
    }

    protected Map<String,String> getParams() throws AuthFailureError{
        return map;
    }
}
